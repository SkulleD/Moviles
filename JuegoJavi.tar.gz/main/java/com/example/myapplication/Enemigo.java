package com.example.myapplication;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;

import java.util.ArrayList;

public class Enemigo {
    int x, y;
    Rect hitbox;
    int color;
    int velocidadx;
    Paint paint;
    int sx,sy;
    boolean selecctionado=false;
    int tickCambio=10000;
    long tiempo=0;
    Bitmap imagen;

    public Enemigo(int x, int y, int sx, int sy, int velocidadx, int color, Bitmap imagen) {
        this.x = x;
        this.y = y;
        this.color=color;
        this.velocidadx=velocidadx;
        this.sx=sx;
        this.sy=sy;
        this.imagen=imagen;



        this.paint=new Paint();
        this.paint.setColor(color);
        this.paint.setStyle(Paint.Style.STROKE);
        this.paint.setStrokeWidth(10);

        hitbox=new Rect(x,y,x+sx,y+sy);

    }

    public  void dibujar(Canvas c){


        c.drawBitmap(imagen,x,y,null);
       // c.drawRect(hitbox,paint);
    }

    public void actualizaHitbox(){
        hitbox=new Rect(x,y,x+sx,y+sy);
    }

    public void mover(){
       if (!selecctionado) {
           x += velocidadx;
           if (x + sx > Juego.anchoPantalla) {
               x = Juego.anchoPantalla - sx;
               velocidadx *= -1;
           } else {
               if (x < 0) {
                   velocidadx *= -1;
                   x = 0;
               }
           }
       }

       if (selecctionado){
           if (System.currentTimeMillis()-tiempo>tickCambio){
               selecctionado=false;
               cambioBorde();
           }
       }

        actualizaHitbox();
    }


    public void cambioBorde(){
        if (selecctionado) {
            paint.setStyle(Paint.Style.FILL);
            tiempo=System.currentTimeMillis();
        }else paint.setStyle(Paint.Style.STROKE);
    }

    public void onTouch(MotionEvent evento){
        if (evento.getAction()==MotionEvent.ACTION_DOWN) {
            if (hitbox.contains((int) evento.getX(), (int) evento.getY())) {
                selecctionado = !selecctionado;
                cambioBorde();
            }
        }else if (evento.getAction()==MotionEvent.ACTION_MOVE) {
            if (selecctionado) {
                x=(int)evento.getX()-sx/2;
                y=(int)evento.getY()-sy/2;
                actualizaHitbox();
            }
        }
    }
}