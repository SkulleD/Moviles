package com.example.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

public class Juego extends View {
   static int anchoPantalla, altaPantalla;
    Paint paint,paint2;
    int color;
    Rect rectangulo,r2;
    RectF rectagulof;
    boolean finJuego=false;

    ArrayList<Enemigo> enemigos;
    Bitmap[] imagens=new Bitmap[]{
            BitmapFactory.decodeResource(getResources(),R.drawable.nave1),
            BitmapFactory.decodeResource(getResources(),R.drawable.nave2),
            BitmapFactory.decodeResource(getResources(),R.drawable.nave3),
            BitmapFactory.decodeResource(getResources(),R.drawable.nave4),
            BitmapFactory.decodeResource(getResources(),R.drawable.nave5),

    };


    public Juego(Context context) {
        super(context);
        paint=new Paint();
        paint.setColor(Color.BLUE);

        color=Color.RED;
        paint.setTextSize(50);
        rectangulo=new Rect(300,350,600,500);
r2=new Rect(10,10,200,200);
        paint2=new Paint();
        paint2.setColor(Color.YELLOW);
        paint2.setStyle(Paint.Style.STROKE);
        paint2.setStrokeWidth(10);






    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(color);
        canvas.drawText(anchoPantalla+":"+altaPantalla,200,200,paint);


        for(Enemigo e:enemigos){
            e.mover();
            e.dibujar(canvas);
        }

        invalidate();

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        int accion=event.getAction();
        int x=(int)event.getX();
        int y=(int)event.getY();

        switch (accion){
            case MotionEvent.ACTION_DOWN:
//            if (x<anchoPantalla/2){
//                if (y<altaPantalla/2) color=Color.GREEN;
//                else color=Color.RED;
//            }
//            else {
//                if (y<altaPantalla/2) color=Color.YELLOW;
//                else  color=Color.MAGENTA;
//            }
//                if (x>=rectangulo.left && x<=rectangulo.right&& y>=rectangulo.top && y<=rectangulo.bottom){
//
//                }
//
                for (Enemigo e:enemigos) e.onTouch(event);

                if (rectangulo.contains(x,y)){
                    finJuego=true;
                }

                return true;
            case MotionEvent.ACTION_UP:


                return true;

            case MotionEvent.ACTION_MOVE:
                for (Enemigo e:enemigos) e.onTouch(event);
                return true;
        }


        return super.onTouchEvent(event);
    }


    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        this.anchoPantalla=w;
        this.altaPantalla=h;


        int partex=anchoPantalla/20;
        int parteY=altaPantalla/10;



        enemigos=new ArrayList<>();
        int cont=0;
        enemigos.add(new Enemigo(partex*2,parteY*2,partex*2,partex*2,partex/2,Color.BLUE,imagens[cont]));
       enemigos.add(new Enemigo(partex*3,parteY*4,partex*2,partex*2,partex/5,Color.GREEN,imagens[cont]));
        enemigos.add(new Enemigo(partex*5,parteY*5,partex*2,partex*3,partex/10,Color.YELLOW,imagens[cont]));
        enemigos.add(new Enemigo(partex*10,parteY*7,partex*2,parteY*2,partex/5,Color.MAGENTA,imagens[cont]));
        enemigos.add(new Enemigo(partex*15,parteY*8,partex*2,parteY*3,partex/7,Color.GRAY,imagens[cont]));
    }
}
