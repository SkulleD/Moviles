package com.mygdx.byebee.characters;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector3;
import com.mygdx.byebee.screens.ByeBee;

import org.w3c.dom.css.Rect;

import java.awt.Canvas;
import java.awt.Paint;

public class Bee extends Character {
    private static final int GRAVITY = -2;

    public Bee(float speed, float posX, float posY, float width, float height, Texture texture) {
        super(speed, posX, posY, width, height, texture);
    }

    //public void fly() {
    //    velocity.y = 200;
    //}
}