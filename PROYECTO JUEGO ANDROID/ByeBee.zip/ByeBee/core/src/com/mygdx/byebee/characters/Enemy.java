package com.mygdx.byebee.characters;

import com.badlogic.gdx.graphics.Texture;

public class Enemy extends Character {
    public Enemy(float speed, float posX, float posY, float width, float height, Texture texture) {
        super(speed, posX, posY, width, height, texture);
    }
}
