package com.mygdx.byebee.screens;

import com.badlogic.gdx.Screen;

public class InfoScreen implements Screen {
    private ByeBee byebee;

    public InfoScreen(ByeBee byebee) {
        this.byebee = byebee;
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
