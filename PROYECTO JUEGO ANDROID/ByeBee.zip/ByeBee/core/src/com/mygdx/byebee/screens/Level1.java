package com.mygdx.byebee.screens;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.byebee.characters.Bee;
import com.mygdx.byebee.characters.Enemy;

public class Level1 implements Screen {
    private Camera camera;
    private Viewport viewport;
    private SpriteBatch spriteBatch;

    private Texture[] backgrounds;

    private float[] bgOffsets = {0, 0, 0, 0}; // Para el efecto parallax
    private float bgMaxScrollSpeed; // Para el movimiento del escenario

    // Personaje controlable
    private Bee bee;

    // Enemigos
    private Enemy bird;
    private Enemy beeLancer;

    public Level1() {
        camera = new OrthographicCamera();
        viewport = new StretchViewport(ByeBee.WIDTH, ByeBee.HEIGHT, camera);

        backgrounds = new Texture[4];
        backgrounds[0] = new Texture("lvl1_background3.png");
        backgrounds[1] = new Texture("lvl1_background2.png");
        backgrounds[2] = new Texture("lvl1_background1.png");
        backgrounds[3] = new Texture("lvl1_foreground.png");
        bgMaxScrollSpeed = (float) (ByeBee.WIDTH / 4);

        bee = new Bee(ByeBee.WIDTH / 6, ByeBee.HEIGHT / 3, 150, 150, new Texture("bee.png"));
        bird = new Enemy(ByeBee.WIDTH / 2, (float) (Math.random() * ByeBee.HEIGHT + 1), 250, 200, new Texture("bird.png"));
        beeLancer = new Enemy(ByeBee.WIDTH / 2, (float) (Math.random() * ByeBee.HEIGHT + 1), 170, 170, new Texture("bee_lancer.png"));

        spriteBatch = new SpriteBatch();
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float deltaTime) {
        bee.fly();
        bird.move();
        beeLancer.move();
        bee.update(deltaTime);
        bird.update(deltaTime);
        beeLancer.update(deltaTime);
        spriteBatch.begin();

        // Muestra fondo parallax
        renderBackground(deltaTime);
        spriteBatch.draw(bee.getTexture(), bee.getPosX(), bee.getPosY(), bee.getWidth(), bee.getHeight());

        spriteBatch.draw(beeLancer.getTexture(), beeLancer.getPosX(), beeLancer.getPosY(), beeLancer.getWidth(), beeLancer.getHeight());

        if (bird.getPosX() > 0) { // En teoría borra al pájaro al salirse de la pantalla, más tarde lo comprobaremos
            spriteBatch.draw(bird.getTexture(), bird.getPosX(), bird.getPosY(), bird.getWidth(), bird.getHeight());
        } else {

        }

        // Detecta colisiones entre la abeja y los enemigos
        detectCollisions();

        // Hace que tu abeja salte hacia arriba al tocar la pantalla
        touchInput();

        spriteBatch.end();
    }

    private void renderBackground(float deltaTime) { // Método para mostrar el fondo con efecto parallax
        bgOffsets[0] += deltaTime * bgMaxScrollSpeed / 8;
        bgOffsets[1] += deltaTime * bgMaxScrollSpeed / 4;
        bgOffsets[2] += deltaTime * bgMaxScrollSpeed / 2;
        bgOffsets[3] += deltaTime * bgMaxScrollSpeed;

        for (int layer = 0; layer < bgOffsets.length; layer++) { // Va recorriendo las capas del fondo y mostrándolas
            if (bgOffsets[layer] > ByeBee.WIDTH) {
                bgOffsets[layer] = 0;
            }

            spriteBatch.draw(backgrounds[layer], -bgOffsets[layer], 0, ByeBee.WIDTH, ByeBee.HEIGHT);
            spriteBatch.draw(backgrounds[layer], -bgOffsets[layer] + ByeBee.WIDTH, 0, ByeBee.WIDTH, ByeBee.HEIGHT);
        }
    }

    private void detectCollisions() {
        if (bee.intersects(bird.getHitbox())) {
            bee.setSpeed(new Vector2(0, 50));
        }
    }

    private void touchInput() {
        // Para que la abeja no puede salirse por encima o debajo de la pantalla
        float topLimit = 0;
        float bottomLimit = ByeBee.HEIGHT;


    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
        spriteBatch.setProjectionMatrix(camera.combined);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
