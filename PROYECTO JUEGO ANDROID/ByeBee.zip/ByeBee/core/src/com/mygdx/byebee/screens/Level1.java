package com.mygdx.byebee.screens;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.byebee.characters.Bee;
import com.mygdx.byebee.characters.Enemy;

public class Level1 implements Screen {
    private Camera camera;
    private Viewport viewport;
    private SpriteBatch spriteBatch;

    private Texture[] backgrounds;

    private float[] bgOffsets = {0, 0, 0, 0}; // Para el efecto parallax
    private float bgMaxScrollSpeed; // Para el movimiento del escenario

    // Personaje controlable
    private Bee bee;

    // Enemigos
    private Enemy bird;
    private Enemy beeLancer;

    public Level1() {
        camera = new OrthographicCamera();
        viewport = new StretchViewport(ByeBee.WIDTH, ByeBee.HEIGHT, camera);

        backgrounds = new Texture[4];
        backgrounds[0] = new Texture("lvl1_background3.png");
        backgrounds[1] = new Texture("lvl1_background2.png");
        backgrounds[2] = new Texture("lvl1_background1.png");
        backgrounds[3] = new Texture("lvl1_foreground.png");
        bgMaxScrollSpeed = (float) (ByeBee.WIDTH / 4);

        bee = new Bee(50, ByeBee.WIDTH / 6, ByeBee.HEIGHT / 3, 150, 150, new Texture("bee.png"));
        bird = new Enemy(60, ByeBee.WIDTH / 2, (float) (Math.random() * ByeBee.HEIGHT + 1), 250, 200, new Texture("bird.png"));
        beeLancer = new Enemy(50, ByeBee.WIDTH / 2, (float) (Math.random() * ByeBee.HEIGHT + 1), 170, 170, new Texture("bee_lancer.png"));

        spriteBatch = new SpriteBatch();
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float deltaTime) {
        spriteBatch.begin();

        renderBackground(deltaTime);
        spriteBatch.draw(bee.getTexture(), bee.getPosX(), bee.getPosY(), bee.getWidth(), bee.getHeight());
        spriteBatch.draw(bird.getTexture(), bird.getPosX(), bird.getPosY(), bird.getWidth(), bird.getHeight());
        spriteBatch.draw(beeLancer.getTexture(), beeLancer.getPosX(), beeLancer.getPosY(), beeLancer.getWidth(), beeLancer.getHeight());

        spriteBatch.end();
    }

    private void renderBackground(float deltaTime) { // Método para mostrar el fondo con efecto parallax
        bgOffsets[0] += deltaTime * bgMaxScrollSpeed / 8;
        bgOffsets[1] += deltaTime * bgMaxScrollSpeed / 4;
        bgOffsets[2] += deltaTime * bgMaxScrollSpeed / 2;
        bgOffsets[3] += deltaTime * bgMaxScrollSpeed;

        for (int layer = 0; layer < bgOffsets.length; layer++) { // Va recorriendo las capas del fondo y mostrándolas
            if (bgOffsets[layer] > ByeBee.WIDTH) {
                bgOffsets[layer] = 0;
            }

            spriteBatch.draw(backgrounds[layer], -bgOffsets[layer], 0, ByeBee.WIDTH, ByeBee.HEIGHT);
            spriteBatch.draw(backgrounds[layer], -bgOffsets[layer] + ByeBee.WIDTH, 0, ByeBee.WIDTH, ByeBee.HEIGHT);

        }
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
        spriteBatch.setProjectionMatrix(camera.combined);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
