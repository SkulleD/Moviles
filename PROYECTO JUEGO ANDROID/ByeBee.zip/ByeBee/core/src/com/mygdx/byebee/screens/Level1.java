package com.mygdx.byebee.screens;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

public class Level1 implements Screen {
    private Camera camera;
    private Viewport viewport;
    private SpriteBatch spriteBatch;

    private Texture level1_bg2;
    private Texture level1_bg3;
    private Texture level1_fg;
    private Texture level1_bg1;
    private int bgOffset; // Para el movimiento del escenario

    public Level1() {
        camera = new OrthographicCamera();
        viewport = new StretchViewport(ByeBee.WIDTH, ByeBee.HEIGHT, camera);

        level1_bg3 = new Texture("lvl1_background3.png");
        level1_bg2 = new Texture("lvl1_background2.png");
        level1_bg1 = new Texture("lvl1_background1.png");
        level1_fg = new Texture("lvl1_foreground.png");

        spriteBatch = new SpriteBatch();
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        spriteBatch.begin();

        // Scroll del escenario
        bgOffset++;

        if (bgOffset % ByeBee.WIDTH == 0) {
            bgOffset = 0;
        }

        spriteBatch.draw(level1_bg3, -bgOffset, 0, ByeBee.WIDTH, ByeBee.HEIGHT);
        spriteBatch.draw(level1_bg2, -bgOffset, 0, ByeBee.WIDTH, ByeBee.HEIGHT);
        spriteBatch.draw(level1_bg1, -bgOffset, 0, ByeBee.WIDTH, ByeBee.HEIGHT);
        spriteBatch.draw(level1_fg, -bgOffset, 0, ByeBee.WIDTH, ByeBee.HEIGHT);

        // Se añade la misma imagen justo después de la actual para que sea seamless
        spriteBatch.draw(level1_bg3, -bgOffset + ByeBee.WIDTH, 0, ByeBee.WIDTH, ByeBee.HEIGHT);
        spriteBatch.draw(level1_bg2, -bgOffset + ByeBee.WIDTH, 0, ByeBee.WIDTH, ByeBee.HEIGHT);
        spriteBatch.draw(level1_bg1, -bgOffset + ByeBee.WIDTH, 0, ByeBee.WIDTH, ByeBee.HEIGHT);
        spriteBatch.draw(level1_fg, -bgOffset + ByeBee.WIDTH, 0, ByeBee.WIDTH, ByeBee.HEIGHT);
        spriteBatch.end();
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
        spriteBatch.setProjectionMatrix(camera.combined);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
