package com.mygdx.byebee.screens;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.byebee.characters.Bee;
import com.mygdx.byebee.characters.Enemy;

import java.util.LinkedList;
import java.util.ListIterator;

public class Level1 implements Screen {
    private Camera camera;
    private Viewport viewport;
    private SpriteBatch spriteBatch;

    private Texture[] backgrounds;

    // Timing thingies
    private float[] bgOffsets = {0, 0, 0, 0}; // Para el efecto parallax
    private float bgMaxScrollSpeed; // Para el movimiento del escenario
    private float timeBetweenEnemySpawns = 3f;
    private float enemySpawnTimer = 0;

    // Personaje controlable
    private Bee bee;

    // Enemigos
    private LinkedList<Enemy> enemyList;
    private Enemy bird;
    private Enemy beeLancer;

    public Level1() {
        camera = new OrthographicCamera();
        viewport = new StretchViewport(ByeBee.WIDTH, ByeBee.HEIGHT, camera);

        backgrounds = new Texture[4];
        backgrounds[0] = new Texture("lvl1_background3.png");
        backgrounds[1] = new Texture("lvl1_background2.png");
        backgrounds[2] = new Texture("lvl1_background1.png");
        backgrounds[3] = new Texture("lvl1_foreground.png");
        bgMaxScrollSpeed = (float) (ByeBee.WIDTH / 4);

        bee = new Bee(ByeBee.WIDTH / 6, ByeBee.HEIGHT / 3,
                150, 150, new Texture("bee.png"));
        //beeLancer = new Enemy(ByeBee.WIDTH / 2, (float) (Math.random() * ByeBee.HEIGHT + 1),
        //        170, 170, new Texture("bee_lancer.png"));

        spriteBatch = new SpriteBatch();
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float deltaTime) {
        // Llamada a métodos de personajes
        bee.fly();
        bee.update(deltaTime);

        // Muestra fondo parallax
        spriteBatch.begin();

        renderBackground(deltaTime);
        spriteBatch.draw(bee.getTexture(), bee.getPosX(), bee.getPosY(), bee.getWidth(), bee.getHeight());

        // Los enemigos van apareciendo aleatoriamente cada cierto tiempo
        ListIterator<Enemy> enemyListIterator = enemyList.listIterator();

        while (enemyListIterator.hasNext()) {
            bird.move();
            beeLancer.move();
            bird.update(deltaTime);
            beeLancer.update(deltaTime);

            // Los enemigos aparecen mientras no se salgan de la pantalla por la izquierda
            if (bird.getPosX() > 0) {
                spriteBatch.draw(bird.getTexture(), bird.getPosX(), bird.getPosY(), bird.getWidth(), bird.getHeight());
            }

            if (beeLancer.getPosX() > 0) {
                spriteBatch.draw(beeLancer.getTexture(), beeLancer.getPosX(), beeLancer.getPosY(), beeLancer.getWidth(), beeLancer.getHeight());
            }

            // Detecta colisiones entre la abeja y los enemigos
            detectCollisions();
        }
        spawnEnemies(deltaTime);

        spriteBatch.end();
    }

    private void renderBackground(float deltaTime) { // Método para mostrar el fondo con efecto parallax
        bgOffsets[0] += deltaTime * bgMaxScrollSpeed / 8;
        bgOffsets[1] += deltaTime * bgMaxScrollSpeed / 4;
        bgOffsets[2] += deltaTime * bgMaxScrollSpeed / 2;
        bgOffsets[3] += deltaTime * bgMaxScrollSpeed;

        for (int layer = 0; layer < bgOffsets.length; layer++) { // Va recorriendo las capas del fondo y mostrándolas
            if (bgOffsets[layer] > ByeBee.WIDTH) {
                bgOffsets[layer] = 0;
            }

            spriteBatch.draw(backgrounds[layer], -bgOffsets[layer], 0, ByeBee.WIDTH, ByeBee.HEIGHT);
            spriteBatch.draw(backgrounds[layer], -bgOffsets[layer] + ByeBee.WIDTH, 0, ByeBee.WIDTH, ByeBee.HEIGHT);
        }
    }

    private void detectCollisions() { // Detecta colisiones de hitboxes
        ListIterator<Enemy> enemyListIterator = enemyList.listIterator();

        while (enemyListIterator.hasNext()) {
            Enemy enemy = enemyListIterator.next();

            if (bee.intersects(enemy.getHitbox())) {
                bee.setSpeed(new Vector2(0, 50)); // Esto es solo de prueba. La abeja perdería 1/7 de vida aquí
                enemyListIterator.remove(); // (DE PRUEBA) borra el enemigo chocado
                break;
            }
        }

    }

    private void spawnEnemies(float deltaTime) { // Hace que los enemigos vayan apareciendo de forma aleatoria
        enemySpawnTimer += deltaTime;

        if (enemySpawnTimer > timeBetweenEnemySpawns) {
            enemyList.add(new Enemy(ByeBee.WIDTH / 2, (float) (Math.random() * ByeBee.HEIGHT + 1),
                    250, 200, new Texture("bird.png")));

            enemySpawnTimer -= timeBetweenEnemySpawns;
        }

    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
        spriteBatch.setProjectionMatrix(camera.combined);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
