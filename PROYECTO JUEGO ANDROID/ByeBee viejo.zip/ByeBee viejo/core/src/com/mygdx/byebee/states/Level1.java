package com.mygdx.byebee.states;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.mygdx.byebee.ByeBee;
import com.mygdx.byebee.characters.Bee;
import com.mygdx.byebee.characters.Bird;

public class Level1 extends State {
    private Bee bee;
    private Bird bird;
    private Texture foreground;
    private Texture background1;
    private Texture background2;
    private Texture background3;

    protected Level1(GameStateManager gsm) {
        super(gsm);
        bee = new Bee(40, 280);
        bird = new Bird(160, 220);
        cam.setToOrtho(false, ByeBee.WIDTH / 2, ByeBee.HEIGHT);
        foreground = new Texture("lvl1_foreground.png");
        background1 = new Texture("lvl1_background1.png");
        background2 = new Texture("lvl1_background2.png");
        background3 = new Texture("lvl1_background3.png");
    }

    @Override
    protected void handleInput() {
        if (Gdx.input.justTouched()) {
            bee.fly();
        }
        bird.move();
    }

    @Override
    public void update(float deltaTime) {
        handleInput();
        bee.update(deltaTime);
        bird.update(deltaTime);
    }

    @Override
    public void render(SpriteBatch spriteBatch) {
        //spriteBatch.setProjectionMatrix(cam.combined);

        spriteBatch.begin();
        //spriteBatch.draw(background, cam.position.x - (cam.viewportHeight / 2), 0);
        spriteBatch.draw(background3, 0, 0, ByeBee.WIDTH, ByeBee.HEIGHT);
        spriteBatch.draw(background2, 0, 0, ByeBee.WIDTH, ByeBee.HEIGHT);
        spriteBatch.draw(background1, 0, 0, ByeBee.WIDTH, ByeBee.HEIGHT);
        spriteBatch.draw(bee.getTexture(), bee.getPosition().x, bee.getPosition().y);
        spriteBatch.draw(bird.getTexture(), 170, bird.getPosition().y);
        spriteBatch.draw(foreground, 0, 0, ByeBee.WIDTH, ByeBee.HEIGHT);
        spriteBatch.end();
    }

    @Override
    public void dispose() {

    }
}
