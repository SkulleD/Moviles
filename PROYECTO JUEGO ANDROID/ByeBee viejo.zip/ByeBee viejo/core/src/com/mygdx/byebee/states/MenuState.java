package com.mygdx.byebee.states;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.mygdx.byebee.ByeBee;

import javax.xml.soap.Text;

public class MenuState extends State{
    private Texture mainMenu;
    private Texture btnPlay;
    private Texture btnCredits;
    private Texture btnOptions;
    private Texture btnInfo;
    private Texture btnRecords;
    private static final int BUTTON_PLAY_Y = 100;

    public MenuState(GameStateManager gsm) {
        super(gsm);
        mainMenu = new Texture("main_menu.png");
        btnPlay = new Texture("btn_jugar.png");
        btnCredits = new Texture("btn_credits.png");
        btnOptions = new Texture("btn_options.png");
        btnInfo = new Texture("btn_info.png");
        btnRecords = new Texture("btn_records.png");
    }

    @Override
    protected void handleInput() {
        int x = ByeBee.WIDTH / 2 - btnPlay.getWidth() / 2;
        if (Gdx.input.justTouched()) {
            gsm.set(new Level1(gsm));
            dispose();
        }
        //if (Gdx.input.getX() < x + btnPlay.getWidth() && Gdx.input.getX() > x && ByeBee.HEIGHT - Gdx.input.getY() < BUTTON_PLAY_Y + btnPlay.getHeight() && ByeBee.HEIGHT - Gdx.input.getY() > BUTTON_PLAY_Y) {

        //}
    }

    @Override
    public void update(float deltaTime) {
        handleInput();
    }

    @Override
    public void render(SpriteBatch spriteBatch) {
        spriteBatch.begin();
        spriteBatch.draw(mainMenu, 0, 0, ByeBee.WIDTH, ByeBee.HEIGHT);
        spriteBatch.draw(btnPlay, ByeBee.WIDTH / 2, ByeBee.HEIGHT / 2);
        spriteBatch.end();
    }

    @Override
    public void dispose() {
        mainMenu.dispose();
    }
}
