package com.example.myapplication;

import android.graphics.Bitmap;
import android.graphics.PointF;
import android.graphics.Rect;

import java.util.Random;

public class Enemigo {
    public PointF posicion;
    public Bitmap sprite;
    public Rect rectangulo;

    public Enemigo (Bitmap sprite, float x, float y) {
        this.sprite = sprite;
        this.posicion = new PointF(x, y);
        setRectangulo();
    }

    public void setRectangulo() {
        float x = posicion.x;
        float y = posicion.y;
        rectangulo = new Rect(
                (int) (x + 0 * sprite.getWidth()),
                (int) (y + 0 * sprite.getHeight()),
                (int) (x + 1 * sprite.getWidth()),
                (int) (y + 1 * sprite.getHeight()));
    }

    public void moverEnemigo(int alto, int velocidad) {
        posicion.x -= velocidad;

        if (sprite.getHeight() > alto) {
            posicion.y = sprite.getHeight() - alto;
        }
        //posicion.x = ancho - sprite.getWidth();
        //posicion.y = alto - sprite.getHeight();

        setRectangulo();
    }
}
