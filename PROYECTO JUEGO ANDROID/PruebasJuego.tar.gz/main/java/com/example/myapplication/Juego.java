package com.example.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import androidx.annotation.NonNull;

import java.util.Random;

public class Juego extends SurfaceView implements SurfaceHolder.Callback {
    private SurfaceHolder surfaceHolder;
    private int anchoPantalla;
    private int altoPantalla;
    private Context context;
    private Bitmap backgroundTitle;
    private Bitmap backgroundGame;
    private boolean running = false;
    private Hilo hilo;
    private boolean titulo = true;
    private Enemigo beeLancer;
    private Bitmap spriteLancer;
    private Enemigo bird;
    private Bitmap spriteBird;
    private Bee bee;
    private Bitmap spriteBee;

    public Juego(Context context) {
        super(context);
        this.surfaceHolder = getHolder();
        this.surfaceHolder.addCallback(this);
        this.context = context;

        hilo = new Hilo();
        setFocusable(true);
        backgroundTitle = BitmapFactory.decodeResource(context.getResources(), R.drawable.bee_title);
    }

    public void dibujar(Canvas c) {
        try {
            if (!titulo) {
                c.drawBitmap(backgroundGame, 0, 0, null);
                c.drawBitmap(bee.sprite, bee.posicion.x, bee.posicion.y, null);
                c.drawBitmap(beeLancer.sprite, beeLancer.posicion.x, beeLancer.posicion.y, null);
                c.drawBitmap(bird.sprite, bird.posicion.x, bird.posicion.y, null);

                Paint p = new Paint();
                p.setColor(Color.RED);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(5);
                c.drawRect(beeLancer.rectangulo, p);
                c.drawRect(bird.rectangulo, p);
                c.drawRect(bee.rectangulo, p);
            }
            else {
                c.drawBitmap(backgroundTitle, 0, 0, null);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

   public void actualizarFisica() {
       if (!titulo) {
           beeLancer.moverEnemigo(altoPantalla, 3);
           bird.moverEnemigo(altoPantalla, 5);
       }
/*        for (Rect rect : bee.rectangulos) {
            if (rect.intersect(beeLancer.rectangulo)) {
                running = false;
                bee.sprite = BitmapFactory.decodeResource(getResources(), R.drawable.nave_destruida);
            }

            if (rect.intersect(bird.rectangulo)) {
                running = false;
                bee.sprite = BitmapFactory.decodeResource(getResources(), R.drawable.nave_destruida);
            }
        }*/
   }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        synchronized (surfaceHolder) {
            int accion = event.getAction();
            float x = event.getX();
            float y = event.getY();

            switch (accion) {
                case MotionEvent.ACTION_DOWN:
                    if (titulo) {
                        backgroundGame = BitmapFactory.decodeResource(getResources(), R.drawable.bee_parallax);
                        backgroundGame = Bitmap.createScaledBitmap(backgroundGame, anchoPantalla, altoPantalla, true);
                        titulo = false;
                    }
                    break;
                case MotionEvent.ACTION_UP:
                    if (!titulo) {
                        bee.saltoCorto(altoPantalla, 20);
                    }
                    break;
            }
        }

        return true;
    }

    @Override
    public void surfaceCreated(@NonNull SurfaceHolder surfaceHolder) {
        hilo.setRunning(true);

        if (hilo.getState() == Thread.State.NEW) {
            hilo.start();
        }

        if (hilo.getState() == Thread.State.TERMINATED) {
            hilo = new Hilo();
            hilo.start();
        }
    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder, int format, int width, int height) {
        anchoPantalla = width;
        altoPantalla = height;
        hilo.setSurfaceSize(width, height);
    }

    @Override
    public void surfaceDestroyed(@NonNull SurfaceHolder surfaceHolder) {
        hilo.setRunning(false);

        try {
            hilo.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    class Hilo extends Thread {
        public Hilo() {

        }

        @Override
        public void run() {
            while (running) {
                Canvas c = null;

                try {
                        c = surfaceHolder.lockCanvas();

                        synchronized (surfaceHolder) {
                                actualizarFisica();
                                dibujar(c);
                         }
                } finally {
                    if (c != null) {
                        surfaceHolder.unlockCanvasAndPost(c);
                    }
                }
            }
        }

        public void setRunning(boolean flag) {
            running = flag;
        }

        public void setSurfaceSize(int width, int height) {
            synchronized (surfaceHolder) {
                if (backgroundTitle != null) {
                    backgroundTitle = Bitmap.createScaledBitmap(backgroundTitle, width, height, true);
                }

                if (backgroundGame != null) {
                    backgroundGame = Bitmap.createScaledBitmap(backgroundGame, width, height, true);
                }

                spriteBee = BitmapFactory.decodeResource(context.getResources(), R.drawable.bee);
                bee = new Bee(spriteBee, (anchoPantalla - spriteBee.getWidth()) / 8, (int) (0.5 * altoPantalla));
                spriteLancer = BitmapFactory.decodeResource(context.getResources(), R.drawable.bee_lancer);
                beeLancer = new Enemigo(spriteLancer, anchoPantalla, (float) (Math.random() * altoPantalla));
                spriteBird = BitmapFactory.decodeResource(context.getResources(), R.drawable.bird);
                bird = new Enemigo(spriteBird, anchoPantalla, (float) (Math.random() * altoPantalla));
            }
        }
    }
}