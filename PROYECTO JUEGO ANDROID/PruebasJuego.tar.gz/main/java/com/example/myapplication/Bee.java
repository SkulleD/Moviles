package com.example.myapplication;

import android.graphics.Bitmap;
import android.graphics.PointF;
import android.graphics.Rect;

public class Bee {
    public PointF posicion;
    public Bitmap sprite;
    public Rect rectangulo;

    public Bee(Bitmap sprite, float x, float y) {
        this.sprite = sprite;
        this.posicion = new PointF(x, y);
        setRectangulo();
        gravedad(15);
    }

    public void setRectangulo() {
        int anchoNave = sprite.getWidth();
        int altoNave = sprite.getHeight();
        float x = posicion.x;
        float y = posicion.y;
        rectangulo = new Rect(
                (int) (x + 0 * sprite.getWidth()),
                (int) (y + 0 * sprite.getHeight()),
                (int) (x + 1 * sprite.getWidth()),
                (int) (y + 1 * sprite.getHeight()));
    }

    public void saltoCorto(int alto, int velocidad) {
        posicion.y -= velocidad;
        setRectangulo();
    }

    public void gravedad(int velocidad) {
        int y0 = 0;
        int y = 0;
        double t = 0.0;
        double gravedad = -9.8;

        setRectangulo();
    }
}