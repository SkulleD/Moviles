package com.alvarovila.gestorpeliculasalvaro;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Element;

import java.util.ArrayList;

public class ListadoAdapter extends RecyclerView.Adapter<ListadoAdapter.ElementoListado>{
    ArrayList<Pelicula> peliculas;

    public ListadoAdapter(ArrayList<Pelicula> peliculas) {
        this.peliculas = peliculas;
    }

    @NonNull
    @Override
    public ElementoListado onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View viewElemento = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_elemento_listado, parent, false);
        ElementoListado elemento = new ElementoListado(viewElemento);
        return elemento;
    }

    @Override
    public void onBindViewHolder(@NonNull ListadoAdapter.ElementoListado holder, int position) {
        holder.titulo.setText(peliculas.get(position).getTitulo());
        holder.director.setText("Director/a: " + peliculas.get(position).getDirector());
        //holder.fecha.setText(peliculas.get(position).getFecha());
        holder.duracion.setText("Duración: " + peliculas.get(position).getDuracion() + "");
        holder.sala.setText("Sala: " + peliculas.get(position).getSala());
        holder.poster.setImageResource(peliculas.get(position).getPortada());
        holder.edades.setImageResource(peliculas.get(position).getClasi());

    }

    @Override
    public int getItemCount() {
        return peliculas.size();
    }

    class ElementoListado extends RecyclerView.ViewHolder {
        TextView titulo;
        TextView director;
        TextView fecha;
        TextView duracion;
        TextView sala;
        ImageView poster;
        ImageView edades;

        public ElementoListado(@NonNull View itemView) {
            super(itemView);
            titulo = itemView.findViewById(R.id.textTituloList);
            director = itemView.findViewById(R.id.textDirectorList);
            fecha = itemView.findViewById(R.id.textFechaList);
            duracion = itemView.findViewById(R.id.textDuracionList);
            sala = itemView.findViewById(R.id.textSalaList);
            poster = itemView.findViewById(R.id.imagePosterList);
            edades = itemView.findViewById(R.id.imageEdadesList);
        }
    }
}
