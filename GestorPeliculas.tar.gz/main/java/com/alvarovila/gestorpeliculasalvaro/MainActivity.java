package com.alvarovila.gestorpeliculasalvaro;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<Pelicula> peliculas;
    RecyclerView rv;
    PeliAdapter peliAdapter;
    Datos datos;
    boolean btnPulsado = false;
    ActivityResultLauncher<Intent> launcher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FloatingActionButton btnHideBar = findViewById(R.id.btnHideBar);
        datos = new Datos();
        peliculas = datos.rellenaPeliculas();

        rv = findViewById(R.id.recyclerView);
        peliAdapter = new PeliAdapter(peliculas);
        GridLayoutManager grid = new GridLayoutManager(this, 1, GridLayoutManager.VERTICAL, false);
        rv.setLayoutManager(grid);
        rv.setAdapter(peliAdapter);

        launcher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {

            }
        });

        btnHideBar.setOnClickListener(new View.OnClickListener() {
            ActionBar actionbar = getSupportActionBar();

            @Override
            public void onClick(View view) {
                if (!btnPulsado) {
                    btnPulsado = true;
                    actionbar.hide();
                } else {
                    btnPulsado = false;
                    actionbar.show();
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.itemList:
                Intent intent = new Intent(MainActivity.this, ListadoPeliculas.class);
                launcher.launch(intent);
                return true;
            case R.id.itemFavorite:

                return true;
            case R.id.itemAdd:

                return true;
        }

        return super.onOptionsItemSelected(item);
    }
}