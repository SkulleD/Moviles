package com.alvarovila.gestorpeliculasalvaro;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;

import java.util.ArrayList;

public class ListadoPeliculas extends AppCompatActivity {
    ArrayList<Pelicula> peliculas;
    RecyclerView rv;
    ListadoAdapter listadoAdapter;
    Datos datos;
    ActivityResultLauncher<Intent> launcher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listado_peliculas);
        datos = new Datos();
        peliculas = datos.rellenaPeliculas();

        rv = findViewById(R.id.recyclerListado);
        listadoAdapter = new ListadoAdapter(peliculas);
        GridLayoutManager grid = new GridLayoutManager(this, 1, GridLayoutManager.VERTICAL, false);
        rv.setLayoutManager(grid);
        rv.setAdapter(listadoAdapter);

        launcher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {

            }
        });
    }
}