package com.alvarovila.gestorpeliculasalvaro;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PeliAdapter extends RecyclerView.Adapter<PeliAdapter.Elemento> {
    ArrayList<Pelicula> peliculas;

    public PeliAdapter(ArrayList<Pelicula> peliculas) {
        this.peliculas = peliculas;
    }

    @NonNull
    @Override
    public Elemento onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View viewElemento = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_elemento, parent, false);
        Elemento elemento = new Elemento(viewElemento);
        return elemento;
    }

    @Override
    public void onBindViewHolder(@NonNull Elemento holder, int position) {
        holder.titulo.setText(peliculas.get(position).getTitulo());
        holder.director.setText(peliculas.get(position).getDirector());
        holder.poster.setImageResource(peliculas.get(position).getPortada());
        holder.edades.setImageResource(peliculas.get(position).getClasi());
    }

    @Override
    public int getItemCount() {
        return peliculas.size();
    }

    class Elemento extends RecyclerView.ViewHolder {
        TextView titulo;
        TextView director;
        ImageView poster;
        ImageView edades;

        public Elemento(@NonNull View itemView) {
            super(itemView);
            titulo = itemView.findViewById(R.id.textTitulo);
            director = itemView.findViewById(R.id.textDirector);
            poster = itemView.findViewById(R.id.imagePoster);
            edades = itemView.findViewById(R.id.imageEdades);
        }
    }
}
