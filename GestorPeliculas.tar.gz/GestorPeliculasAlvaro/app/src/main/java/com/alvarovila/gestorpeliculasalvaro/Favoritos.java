package com.alvarovila.gestorpeliculasalvaro;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class Favoritos extends AppCompatActivity {
    ArrayList<Pelicula> peliculas;
    ArrayAdapter<String> adapterFavs;
    Datos datos;
    ActivityResultLauncher<Intent> launcher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favoritos);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Películas favoritas");
        datos = new Datos();
        peliculas = datos.rellenaPeliculas();

        ListView listView = findViewById(R.id.listViewFavs);
        //adapterFavs = new ArrayAdapter<String>(R.layout.activity_favoritos, peliculas);
        listView.setAdapter(adapterFavs);


        launcher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {

            }
        });
    }
}