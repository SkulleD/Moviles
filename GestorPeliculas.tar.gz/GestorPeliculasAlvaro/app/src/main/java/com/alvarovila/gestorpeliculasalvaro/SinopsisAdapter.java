package com.alvarovila.gestorpeliculasalvaro;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class SinopsisAdapter extends RecyclerView.Adapter<SinopsisAdapter.ElementoSinopsis> {
    ArrayList<Pelicula> peliculas;

    public SinopsisAdapter(ArrayList<Pelicula> peliculas) {
        this.peliculas = peliculas;
    }

    @NonNull
    @Override
    public SinopsisAdapter.ElementoSinopsis onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View viewElemento = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_sinopsis, parent, false);
       ElementoSinopsis elemento = new ElementoSinopsis(viewElemento);
       return elemento;
    }

    @Override
    public void onBindViewHolder(@NonNull SinopsisAdapter.ElementoSinopsis holder, int position) {
        holder.poster.setImageResource(peliculas.get(position).getPortada());
        holder.sinopsis.setText(peliculas.get(position).getSinopsis());
    }

    @Override
    public int getItemCount() {
        return peliculas.size();
    }

    class ElementoSinopsis extends RecyclerView.ViewHolder {
        ImageView poster;
        TextView sinopsis;

        public ElementoSinopsis(@NonNull View itemView) {
            super(itemView);
            poster = itemView.findViewById(R.id.imagePosterSinopsis);
            sinopsis = itemView.findViewById(R.id.textSinopsis);
        }
    }
}
