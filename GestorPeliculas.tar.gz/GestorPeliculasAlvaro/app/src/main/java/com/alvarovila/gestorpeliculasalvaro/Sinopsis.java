package com.alvarovila.gestorpeliculasalvaro;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;

public class Sinopsis extends AppCompatActivity {
    ArrayList<Pelicula> peliculas;
    RecyclerView rv;
    SinopsisAdapter sinopsisAdapter;
    Datos datos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sinopsis);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Sinopsis");
        datos = new Datos();
        peliculas = datos.rellenaPeliculas();

        rv = findViewById(R.id.recyclerFavs);
        sinopsisAdapter = new SinopsisAdapter(peliculas);
        GridLayoutManager grid = new GridLayoutManager(this, 1, GridLayoutManager.VERTICAL, false);
        rv.setLayoutManager(grid);
        rv.setAdapter(sinopsisAdapter);
    }
}