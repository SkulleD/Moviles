package com.alvarovila.gestorpeliculasalvaro;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PeliAdapter extends RecyclerView.Adapter<PeliAdapter.Elemento> implements View.OnClickListener {
    ArrayList<Pelicula> peliculas;
    private View.OnClickListener listener;
    int selectedPos = RecyclerView.NO_POSITION;

    public PeliAdapter(ArrayList<Pelicula> peliculas) {
        this.peliculas = peliculas;
    }

    public int getSelectedPos() {
        return selectedPos;
    }

    public void setSelectedPos(int selectedPos) {
        if (selectedPos == this.selectedPos) {
            notifyItemChanged(this.selectedPos);
            this.selectedPos = RecyclerView.NO_POSITION;
        } else {
            if (this.selectedPos >= 0) notifyItemChanged(this.selectedPos);
            this.selectedPos = selectedPos;
            notifyItemChanged(this.selectedPos);
        }
        this.selectedPos = selectedPos;
    }

    @NonNull
    @Override
    public Elemento onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View viewElemento = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_elemento, parent, false);
        Elemento elemento = new Elemento(viewElemento);
        viewElemento.setOnClickListener(this);
        return elemento;
    }

    @Override
    public void onBindViewHolder(@NonNull Elemento holder, int position) {
        holder.titulo.setText(peliculas.get(position).getTitulo());
        holder.director.setText(peliculas.get(position).getDirector());
        holder.poster.setImageResource(peliculas.get(position).getPortada());
        holder.edades.setImageResource(peliculas.get(position).getClasi());

        if (selectedPos == position) {
            holder.itemView.setBackgroundResource(R.color.white);
        } else {
            holder.itemView.setBackgroundResource(R.color.white);
        }
    }

    @Override
    public int getItemCount() {
        return peliculas.size();
    }

    @Override
    public void onClick(View view) {
        if (listener !=  null) listener.onClick(view);
    }

    public void setOnClickListener(View.OnClickListener listener) {
        this.listener = listener;
    }

    class Elemento extends RecyclerView.ViewHolder {
        TextView titulo;
        TextView director;
        ImageView poster;
        ImageView edades;

        public Elemento(@NonNull View itemView) {
            super(itemView);
            titulo = itemView.findViewById(R.id.textTitulo);
            director = itemView.findViewById(R.id.textDirector);
            poster = itemView.findViewById(R.id.imagePoster);
            edades = itemView.findViewById(R.id.imageEdades);
        }
    }
}
