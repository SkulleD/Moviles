package com.alvarovila.gestorpeliculasalvaro;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;

public class ListadoPeliculas extends AppCompatActivity {
    ArrayList<Pelicula> peliculas;
    RecyclerView rv;
    ListadoAdapter listadoAdapter;
    Datos datos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listado_peliculas);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Listado Películas");
        datos = new Datos();
        peliculas = datos.rellenaPeliculas();

        rv = findViewById(R.id.recyclerListado);
        listadoAdapter = new ListadoAdapter(peliculas);
        GridLayoutManager grid = new GridLayoutManager(this, 1, GridLayoutManager.VERTICAL, false);
        rv.setLayoutManager(grid);
        rv.setAdapter(listadoAdapter);

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = rv.getChildAdapterPosition(view);
                listadoAdapter.setSelectedPos(pos);

                if (pos >= 0) {
                   Intent intent = new Intent(ListadoPeliculas.this, Sinopsis.class);
                   intent.putExtra("poster", peliculas.get(pos).getPortada());
                   intent.putExtra("sinopsis", peliculas.get(pos).getSinopsis());
                   intent.putExtra("enlace", peliculas.get(pos).getIdYoutube());
                   startActivity(intent);
                }
            }
        };
        listadoAdapter.setOnClickListener(listener);
    }
}