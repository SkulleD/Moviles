package com.alvarovila.gestorpeliculasalvaro;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Element;

import java.util.ArrayList;

public class ListadoAdapter extends RecyclerView.Adapter<ListadoAdapter.ElementoListado> implements View.OnClickListener{
    ArrayList<Pelicula> peliculas;
    private View.OnClickListener listener;
    int selectedPos = RecyclerView.NO_POSITION;

    public ListadoAdapter(ArrayList<Pelicula> peliculas) {
        this.peliculas = peliculas;
    }

    public int getSelectedPos() {
        return selectedPos;
    }

    public void setSelectedPos(int selectedPos) {
        if (selectedPos == this.selectedPos) {
            notifyItemChanged(this.selectedPos);
            this.selectedPos = RecyclerView.NO_POSITION;
        } else {
            if (this.selectedPos >= 0) notifyItemChanged(this.selectedPos);
            this.selectedPos = selectedPos;
            notifyItemChanged(this.selectedPos);
        }
        this.selectedPos = selectedPos;
    }

    @NonNull
    @Override
    public ElementoListado onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View viewElemento = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_elemento_listado, parent, false);
        ElementoListado elemento = new ElementoListado(viewElemento);
        viewElemento.setOnClickListener(this);
        return elemento;
    }

    @Override
    public void onBindViewHolder(@NonNull ListadoAdapter.ElementoListado holder, int position) {
        holder.titulo.setText(peliculas.get(position).getTitulo());
        holder.director.setText("Director/a: " + peliculas.get(position).getDirector());
        //holder.fecha.setText(peliculas.get(position).getFecha());
        holder.duracion.setText("Duración: " + peliculas.get(position).getDuracion() + "");
        holder.sala.setText("Sala: " + peliculas.get(position).getSala());
        holder.poster.setImageResource(peliculas.get(position).getPortada());
        holder.edades.setImageResource(peliculas.get(position).getClasi());

    }

    @Override
    public int getItemCount() {
        return peliculas.size();
    }

    @Override
    public void onClick(View view) {
        if (listener != null) listener.onClick(view);
    }

    public void setOnClickListener(View.OnClickListener listener) {
        this.listener = listener;
    }

    class ElementoListado extends RecyclerView.ViewHolder {
        TextView titulo;
        TextView director;
        TextView fecha;
        TextView duracion;
        TextView sala;
        ImageView poster;
        ImageView edades;

        public ElementoListado(@NonNull View itemView) {
            super(itemView);
            titulo = itemView.findViewById(R.id.textTituloList);
            director = itemView.findViewById(R.id.textDirectorList);
            fecha = itemView.findViewById(R.id.textFechaList);
            duracion = itemView.findViewById(R.id.textDuracionList);
            sala = itemView.findViewById(R.id.textSalaList);
            poster = itemView.findViewById(R.id.imagePosterList);
            edades = itemView.findViewById(R.id.imageEdadesList);
        }
    }
}
