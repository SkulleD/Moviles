package com.alvarovila.gestorpeliculasalvaro;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class Favoritos extends AppCompatActivity {
    ArrayList<Pelicula> peliculas;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favoritos);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Películas favoritas");

        listView = findViewById(R.id.listViewFavs);
        peliculas = (ArrayList<Pelicula>)getIntent().getSerializableExtra("pelis");
        ArrayAdapter<Pelicula> adapterFavs = new ArrayAdapter<>(this, android.R.layout.simple_list_item_checked, peliculas);
        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        listView.setAdapter(adapterFavs);

        for (int i = 0; i < peliculas.size(); i++) {
            listView.setItemChecked(i, peliculas.get(i).getFavorita());
        }
    }

    @Override
    public void onBackPressed() {
        ArrayList<Boolean> fav = new ArrayList<>();

        for (int i = 0; i < peliculas.size(); i++) {
            fav.add(listView.isItemChecked(i));
        }

        Intent intent = new Intent();
        intent.putExtra("fav", fav);
        setResult(RESULT_OK, intent);
        finish();
    }
}