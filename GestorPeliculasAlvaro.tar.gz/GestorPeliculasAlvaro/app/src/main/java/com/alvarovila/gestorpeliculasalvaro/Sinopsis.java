package com.alvarovila.gestorpeliculasalvaro;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Sinopsis extends AppCompatActivity {
    ArrayList<Pelicula> peliculas;
    ImageView poster;
    TextView sinopsis;
    Datos datos;
    String enlace;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sinopsis);
        poster = findViewById(R.id.imagePosterSinopsis);
        sinopsis = findViewById(R.id.textSinopsis);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Sinopsis");
        datos = new Datos();

        Intent intent = getIntent();
        poster.setImageResource(intent.getIntExtra("poster", R.drawable.sincara));
        sinopsis.setText(intent.getStringExtra("sinopsis"));

        poster.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Funciono", Toast.LENGTH_SHORT).show();
                enlace = intent.getStringExtra("enlace");
                watchYoutubeVideo(enlace);
            }
        });
    }

    public  void watchYoutubeVideo(String id){
        Intent appIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:" + id));
        Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.youtube.com/watch?v=" + id));
        try {
            startActivity(appIntent);
        } catch (ActivityNotFoundException ex) {
            startActivity(webIntent);
        }
    }
}