package com.alvarovila.gestorpeliculasalvaro;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class NuevaPeli extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nueva_peli);
    }
}